
import { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FeaturedBooks from '../components/FeaturedBooks';
import BookDetails from '../components/BookDetails';
import ShoppingCart from '../components/ShoppingCart';

export interface Book {
  id: number;
  title: string;
  author: string;
  price: number;
  image: string;
  description: string;
  rating: number;
  genre: string;
  isbn: string;
  pages: number;
  publisher: string;
  publishedDate: string;
}

export interface CartItem extends Book {
  quantity: number;
}

const Index = () => {
  const [currentPage, setCurrentPage] = useState<'home' | 'book-details' | 'cart'>('home');
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const featuredBooks: Book[] = [
    {
      id: 1,
      title: "The Midnight Library",
      author: "Matt Haig",
      price: 24.99,
      image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=600&fit=crop",
      description: "A dazzling novel about all the choices that go into a life well lived, from the internationally bestselling author of Reasons to Stay Alive and How To Stop Time.",
      rating: 4.5,
      genre: "Fiction",
      isbn: "978-0525559474",
      pages: 288,
      publisher: "Viking",
      publishedDate: "2020-08-13"
    },
    {
      id: 2,
      title: "Atomic Habits",
      author: "James Clear",
      price: 18.99,
      image: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=400&h=600&fit=crop",
      description: "An Easy & Proven Way to Build Good Habits & Break Bad Ones. Transform your life with tiny changes in behavior that lead to remarkable results.",
      rating: 4.8,
      genre: "Self-Help",
      isbn: "978-0735211292",
      pages: 320,
      publisher: "Avery",
      publishedDate: "2018-10-16"
    },
    {
      id: 3,
      title: "The Seven Husbands of Evelyn Hugo",
      author: "Taylor Jenkins Reid",
      price: 16.99,
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop",
      description: "A reclusive Hollywood icon finally tells her story in this captivating novel that will keep you turning pages late into the night.",
      rating: 4.7,
      genre: "Historical Fiction",
      isbn: "978-1501161933",
      pages: 400,
      publisher: "Atria Books",
      publishedDate: "2017-06-13"
    },
    {
      id: 4,
      title: "Educated",
      author: "Tara Westover",
      price: 22.50,
      image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400&h=600&fit=crop",
      description: "A memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.",
      rating: 4.6,
      genre: "Memoir",
      isbn: "978-0399590504",
      pages: 334,
      publisher: "Random House",
      publishedDate: "2018-02-20"
    },
    {
      id: 5,
      title: "The Psychology of Money",
      author: "Morgan Housel",
      price: 19.99,
      image: "https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400&h=600&fit=crop",
      description: "Timeless lessons on wealth, greed, and happiness. How your psychology affects your financial decisions more than you think.",
      rating: 4.4,
      genre: "Finance",
      isbn: "978-0857197689",
      pages: 252,
      publisher: "Harriman House",
      publishedDate: "2020-09-08"
    },
    {
      id: 6,
      title: "Project Hail Mary",
      author: "Andy Weir",
      price: 21.99,
      image: "https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=400&h=600&fit=crop",
      description: "A lone astronaut must save the earth from disaster in this incredible new science-based thriller from the bestselling author of The Martian.",
      rating: 4.9,
      genre: "Science Fiction",
      isbn: "978-0593135204",
      pages: 496,
      publisher: "Ballantine Books",
      publishedDate: "2021-05-04"
    }
  ];

  const addToCart = (book: Book) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === book.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === book.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevItems, { ...book, quantity: 1 }];
      }
    });
  };

  const removeFromCart = (bookId: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== bookId));
  };

  const updateQuantity = (bookId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(bookId);
      return;
    }
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === bookId ? { ...item, quantity } : item
      )
    );
  };

  const handleBookClick = (book: Book) => {
    setSelectedBook(book);
    setCurrentPage('book-details');
  };

  const navigateToCart = () => {
    setCurrentPage('cart');
  };

  const navigateToHome = () => {
    setCurrentPage('home');
  };

  const getCartItemCount = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      <Header 
        currentPage={currentPage} 
        cartItemCount={getCartItemCount()}
        onNavigateHome={navigateToHome}
        onNavigateCart={navigateToCart}
      />
      
      <main className="min-h-screen">
        {currentPage === 'home' && (
          <FeaturedBooks 
            books={featuredBooks} 
            onBookClick={handleBookClick}
          />
        )}
        
        {currentPage === 'book-details' && selectedBook && (
          <BookDetails 
            book={selectedBook} 
            onAddToCart={addToCart}
            onBackToHome={navigateToHome}
          />
        )}
        
        {currentPage === 'cart' && (
          <ShoppingCart 
            cartItems={cartItems}
            onRemoveFromCart={removeFromCart}
            onUpdateQuantity={updateQuantity}
            onBackToHome={navigateToHome}
          />
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
